package com.sipocotdj.tripticket;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;
import android.location.Geocoder;
import android.location.Address;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private LinearLayout root, form;
    private final Map<String, EditText> fields = new LinkedHashMap<>();
    private TextView distanceView, statusView;
    private TextView photoMetaView;
    private final ImageView[] photoPreviews = new ImageView[5];
    private final String[] photoMeta = new String[]{"", "not captured", "not captured", "not captured", "not captured"};
    private final String[] liveGps = new String[]{"", "not captured", "not captured", "not captured", "not captured"};
    private static final String[] PHOTO_LABELS = {"", "DEPARTURE FROM JAIL / OFFICE", "ARRIVAL AT DESTINATION", "DEPARTURE FROM DESTINATION", "RETURN TO JAIL / OFFICE"};
    private final String[] evidencePhotoFiles = new String[]{"", "", "", "", ""};
    private SignatureView signature;
    private int scanTarget = 0; // 1 departure, 2 arrival
    private static final int PICK_IMAGE = 301;
    private FusedLocationProviderClient fusedLocationClient;
    private int pendingGpsTarget=0;
    private static final int GPS_PERMISSION_REQUEST=701;
    private static final String[] DRIVER_SUGGESTIONS = {
        "JO1 Carl Benedict C. Dineros", "JO1 Jomar V. Ibana", "JO1 Angelo Cutia",
        "JO1 John Ernest Chavez", "JO1 Turiano", "JO1 Lontoc", "JO1 Magdaraog",
        "JO1 Collantes", "JO1 Vince Rodrigo A. Roño", "JO1 Darwin Collantes",
        "JO1 Sarah Jane S. Ibarreta", "JO1 Kyla Graciel L. Orbita",
        "JO1 Ramelle A. Mandaraog", "JO1 Jeffrey Daep", "JO3 Ariel B. Pontanilla",
        "JO2 Jacell C. Acosta"
    };
    private static final String[] VEHICLE_SUGGESTIONS = {
        "Mitsubishi L300 / SAB 9894"
    };
    private static final String[] DESTINATION_SUGGESTIONS = {
        "Municipal Hall, Sipocot", "MCTC Sipocot", "RTC Libmanan",
        "BJMP Regional Office V, Legazpi City", "Provincial Jail, Pili, Camarines Sur",
        "Municipal Hall, Lupi", "Municipal Hall, Ragay", "Municipal Hall, Del Gallego",
        "Municipal Hall, Cabusao", "Municipal Hall, Libmanan", "Other - Enter Manually"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        fusedLocationClient=LocationServices.getFusedLocationProviderClient(this);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(16),dp(16),dp(28));
        root.setBackgroundColor(Color.rgb(238,242,247)); scroll.addView(root); setContentView(scroll);
        FrameLayout heroFrame = new FrameLayout(this);
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(-1, dp(220));
        heroFrame.setLayoutParams(heroParams);
        ImageView heroImage = new ImageView(this); heroImage.setImageResource(com.sipocotdj.tripticket.R.drawable.vehicle_hero);
        heroImage.setScaleType(ImageView.ScaleType.CENTER_CROP); heroFrame.addView(heroImage, new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this); android.graphics.drawable.GradientDrawable shadeBg = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xEE0B1F36,0x990B1F36,0x110B1F36}); shadeBg.setCornerRadius(dp(20)); shade.setBackground(shadeBg); heroFrame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setGravity(Gravity.BOTTOM); hero.setPadding(dp(20),dp(18),dp(20),dp(20));
        heroFrame.addView(hero,new FrameLayout.LayoutParams(-1,-1)); root.addView(heroFrame);
        TextView eyebrow=text("BUREAU OF JAIL MANAGEMENT & PENOLOGY  •  REGION V",10,true); eyebrow.setTextColor(Color.rgb(213,226,240)); hero.addView(eyebrow);
        TextView title = text("BJMP • SDJ TRIP TICKET",28,true); title.setTextColor(Color.WHITE); title.setPadding(0,dp(5),0,dp(3)); hero.addView(title);
        TextView sub = text("SIPOCOT DISTRICT JAIL  |  OFFICIAL VEHICLE LOGBOOK",11,true); sub.setTextColor(Color.rgb(235,240,246)); hero.addView(sub);
        statusView = text("Ready. Scan the odometer photo to capture its reading, photo time and GPS location.",12,false); statusView.setTextColor(Color.rgb(16,39,68)); statusView.setPadding(dp(12),dp(12),dp(12),dp(12)); statusView.setBackground(round(Color.WHITE,12)); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2);stp.topMargin=dp(12);root.addView(statusView);
        photoMetaView=text("PHOTO METADATA\nDeparture: not captured\nArrival: not captured",11,false);photoMetaView.setTextColor(Color.rgb(16,39,68));photoMetaView.setPadding(dp(12),dp(10),dp(12),dp(10));photoMetaView.setBackground(round(Color.rgb(232,238,246),12));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(8);root.addView(photoMetaView);
        form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); root.addView(form);
        section("TRAVEL DETAILS"); addField("Travel Order No.","travelOrder"); addField("Date (e.g. November 16, 2026)","date",new SimpleDateFormat("MMMM d, yyyy",Locale.US).format(new Date()));
        addSuggestField("Driver's Full Name (select or type) ","driver",loadList("drivers",DRIVER_SUGGESTIONS)); addSuggestField("Government Vehicle / Plate No. (select or type)","vehicle",loadList("vehicles",VEHICLE_SUGGESTIONS));
        addField("Authorized Passenger(s)","passengers"); addSuggestField("Place(s) to be Visited / Inspected (select or type) ","places",loadList("destinations",DESTINATION_SUGGESTIONS)); addField("Purpose of Travel","purpose");
        section("ODOMETER • PHOTO • GPS");
        photoCard("1 • DEPARTURE FROM JAIL / OFFICE",1);
        addField("VEHICLE KILOMETER READER – DEPARTURE (KM)","odoStart","",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        photoCard("2 • ARRIVAL AT DESTINATION",2);
        photoCard("3 • DEPARTURE FROM DESTINATION",3);
        photoCard("4 • RETURN TO JAIL / OFFICE",4);
        addField("VEHICLE KILOMETER READER – RETURN (KM)","odoEnd","",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        distanceView = text("DISTANCE TRAVELED: — KM",18,true); distanceView.setTextColor(Color.rgb(0,105,75)); distanceView.setPadding(0,dp(12),0,dp(12)); form.addView(distanceView);
        fields.get("odoStart").addTextChangedListener(watcher()); fields.get("odoEnd").addTextChangedListener(watcher());
        section("DRIVER'S TRIP RECORD");
        addField("Time of Departure from Office / Garage","timeOut"); addField("Time of Arrival at Destination","timeAtDestination"); addField("Time of Departure from Destination","timeFromDestination"); addField("Time of Arrival Back to Office / Garage","timeIn");
        addField("Gasoline Issued / Purchased / Consumed (Liters)","fuelIssued"); addField("Balance in Tank at Beginning (Liters)","fuelBeginning"); addField("Issued by Office from Stock (Liters)","fuelStock"); addField("Fuel Purchased During Trip (Liters)","fuelPurchased"); addField("Fuel Deducted / Used During Trip (Liters)","fuelUsed"); addField("Balance in Tank at End (Liters)","fuelEnd");
        addField("Gear Oil Issued (Liters)","gearOil"); addField("Lubrication Oil Issued (Liters)","lubricationOil"); addField("Grease Oil Issued (Liters)","greaseOil"); addField("Speedometer Reading at Beginning (KM)","speedStart"); addField("Speedometer Reading at End (KM)","speedEnd"); addField("Remarks","remarks");
        section("AUTHORIZED SIGNATORY & DRIVER SIGNATURE");
        addSuggestField("Chief of Bureau / Warden (editable; manage current and former wardens)","warden",loadList("wardens",new String[]{"JSINSP ISRAELITO D. BARRUN"}));
        addSuggestField("Driver name to appear below certification", "driverSignatory", loadList("drivers",DRIVER_SUGGESTIONS));
        TextView sigHint=text("Draw the driver's signature below. The printed driver name will appear under the signature line.",12,false); form.addView(sigHint);
        signature = new SignatureView(this); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(130)); sp.topMargin=dp(8); sp.bottomMargin=dp(8); signature.setLayoutParams(sp); form.addView(signature);
        addButton("Clear Signature",()->signature.clear());
        addButton("MANAGE DRIVERS, VEHICLES, DESTINATIONS & WARDENS",()->manageMasterlists());
        addButton("GENERATE TRIP TICKET PDF",()->generatePdf());
        addButton("VIEW SAVED TRIP TICKETS",()->showHistory());
        addButton("CLEAR FORM",()->new AlertDialog.Builder(this).setMessage("Clear all entered trip details?").setPositiveButton("Clear",(d,w)->clearForm()).setNegativeButton("Cancel",null).show());
    }

    private void photoCard(String label,int target){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12),dp(12),dp(12),dp(12)); card.setBackground(round(Color.WHITE,16));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(8); cp.bottomMargin=dp(8); form.addView(card,cp);
        TextView heading=text(label,12,true); heading.setTextColor(Color.rgb(25,55,85)); card.addView(heading);
        ImageView preview=new ImageView(this); preview.setBackground(round(Color.rgb(232,238,245),12)); preview.setImageResource(android.R.drawable.ic_menu_camera); preview.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(132)); ip.topMargin=dp(8); card.addView(preview,ip);
        photoPreviews[target]=preview;
        Button capture=new Button(this); capture.setText("TAKE / SELECT PHOTO"); capture.setAllCaps(false); capture.setTextColor(Color.WHITE); capture.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22,65,105))); capture.setOnClickListener(v->pick(target));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(50)); bp.topMargin=dp(6); card.addView(capture,bp);
        TextView note=text("Attach the actual photo taken at this trip stage. Live GPS and capture time are recorded separately.",11,false); note.setTextColor(Color.rgb(95,110,125)); card.addView(note);
    }

    private android.text.TextWatcher watcher(){return new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){updateDistance();} public void afterTextChanged(android.text.Editable e){}};}
    private void updateDistance(){try{double a=Double.parseDouble(val("odoStart")),b=Double.parseDouble(val("odoEnd")); double d=b-a; distanceView.setText(d<0?"CHECK READINGS: Arrival is lower than departure":"DISTANCE TRAVELED: "+fmt(d)+" KM");}catch(Exception e){distanceView.setText("DISTANCE TRAVELED: — KM");}}
    private String fmt(double n){return n==(long)n?String.valueOf((long)n):String.format(Locale.US,"%.1f",n);}
    private void pick(int target){scanTarget=target; Intent i=new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(Intent.createChooser(i,"Choose odometer photo (camera photo recommended)"),PICK_IMAGE);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); if(req==PICK_IMAGE&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData(); statusView.setText("Saving trip-stage photo and reading its metadata…"); saveEvidencePhoto(uri,scanTarget); try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {} ImageView preview=photoPreviews[scanTarget]; if(preview!=null){preview.setImageURI(uri);preview.setScaleType(ImageView.ScaleType.CENTER_CROP);} readPhotoMetadata(uri,scanTarget); captureLiveLocation(scanTarget); if(scanTarget==1||scanTarget==4){try{InputImage image=InputImage.fromFilePath(this,uri);final int target=scanTarget;TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image).addOnSuccessListener(result->{String found=findReading(result.getText());if(found!=null){fields.get(target==1?"odoStart":"odoEnd").setText(found);statusView.setText("Detected odometer: "+found+" KM. Please verify the number before saving.");}else statusView.setText("No clear odometer number detected. Enter the reading manually.");}).addOnFailureListener(e->statusView.setText("Could not read odometer. Please enter it manually."));}catch(Exception e){statusView.setText("Unable to open image. Please try another photo.");}}}}
    private void saveEvidencePhoto(Uri uri,int target){
        try{File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"SDJTripEvidence");if(!dir.exists())dir.mkdirs();File outFile=new File(dir,"stage_"+target+"_"+System.currentTimeMillis()+".jpg");try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(outFile)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}evidencePhotoFiles[target]=outFile.getAbsolutePath();}
        catch(Exception e){evidencePhotoFiles[target]="Photo copy failed: "+e.getMessage();}
    }
    private void captureLiveLocation(int target){
        pendingGpsTarget=target;
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},GPS_PERMISSION_REQUEST);
            statusView.setText("Photo selected. Allow location permission to capture the phone's actual GPS position."); return;
        }
        requestFreshLocation(target);
    }
    private void requestFreshLocation(int target){
        try{
            if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,null).addOnSuccessListener(location->{
                if(location==null){setLiveGps(target,"GPS unavailable — enable Location and try again");return;}
                String coords=String.format(Locale.US,"%.6f, %.6f (±%.0f m)",location.getLatitude(),location.getLongitude(),location.getAccuracy());
                String place="";
                try{if(Geocoder.isPresent()){List<Address> a=new Geocoder(this,Locale.getDefault()).getFromLocation(location.getLatitude(),location.getLongitude(),1);if(a!=null&&!a.isEmpty())place=a.get(0).getAddressLine(0);}}catch(Exception ignored){}
                String record="Live GPS: "+coords+(place.isEmpty()?"":"\nAddress: "+place)+"\nCaptured: "+new SimpleDateFormat("MMM d, yyyy hh:mm:ss a",Locale.getDefault()).format(new Date(location.getTime()));
                setLiveGps(target,record);
            }).addOnFailureListener(e->setLiveGps(target,"GPS capture failed — "+e.getMessage()));
        }catch(Exception e){setLiveGps(target,"GPS unavailable — "+e.getMessage());}
    }
    private void setLiveGps(int target,String value){
        liveGps[target]=value;
        runOnUiThread(()->{updatePhotoMeta();statusView.setText(PHOTO_LABELS[target]+" photo processed. "+value.replace("\n"," • "));});
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==GPS_PERMISSION_REQUEST){boolean granted=false;for(int r:grantResults)if(r==PackageManager.PERMISSION_GRANTED)granted=true;if(granted)requestFreshLocation(pendingGpsTarget);else statusView.setText("Location permission denied. Photo metadata GPS may still be available; live GPS was not captured.");}
    }
    private void readPhotoMetadata(Uri uri,int target){
        String captured="", location=""; double[] latlon=null;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            ExifInterface exif=new ExifInterface(in);
            captured=exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
            if(captured==null||captured.isEmpty())captured=exif.getAttribute(ExifInterface.TAG_DATETIME);
            latlon=exif.getLatLong();
        }catch(Exception ignored){}
        if(captured!=null&&!captured.isEmpty()){
            try{Date d=new SimpleDateFormat("yyyy:MM:dd HH:mm:ss",Locale.US).parse(captured);String time=new SimpleDateFormat("hh:mm a",Locale.US).format(d);String key=target==1?"timeOut":target==2?"timeAtDestination":target==3?"timeFromDestination":"timeIn";fields.get(key).setText(time);}
            catch(Exception ignored){}
        }
        final String photoTime=(captured==null||captured.isEmpty())?"time not stored in photo":captured;
        if(latlon!=null){final double lat=latlon[0],lon=latlon[1];new Thread(()->{String place=String.format(Locale.US,"GPS %.5f, %.5f",lat,lon);try{if(Geocoder.isPresent()){List<Address> a=new Geocoder(this,Locale.getDefault()).getFromLocation(lat,lon,1);if(a!=null&&!a.isEmpty()){Address x=a.get(0);StringBuilder b=new StringBuilder();for(int i=0;i<=x.getMaxAddressLineIndex();i++){if(i>0)b.append(", ");b.append(x.getAddressLine(i));}if(b.length()>0)place=b.toString();}}}catch(Exception ignored){}final String resolved=place;runOnUiThread(()->{String meta="Photo time: "+photoTime+"\nGPS place: "+resolved;photoMeta[target]=meta;if(target==2)fields.get("places").setText(resolved);updatePhotoMeta();});}).start();}
        else{String meta="Photo time: "+photoTime+"\nGPS location: not embedded in photo";photoMeta[target]=meta;updatePhotoMeta();}
    }
    private void updatePhotoMeta(){StringBuilder b=new StringBuilder("FOUR-STAGE PHOTO & GPS VERIFICATION\n");for(int i=1;i<=4;i++)b.append(i).append(". ").append(PHOTO_LABELS[i]).append("\n").append(photoMeta[i]).append("\n").append(liveGps[i]).append("\n\n");photoMetaView.setText(b.toString().trim());}

    private String findReading(String s){Matcher m=Pattern.compile("(?<!\\d)(\\d{2,7}(?:[,.]\\d)?)(?!\\d)").matcher(s.replace(" ","")); String best=null; int max=-1; while(m.find()){String x=m.group(1).replace(",",""); try{int n=(int)Double.parseDouble(x); if(n>max){max=n;best=x;}}catch(Exception ignored){}} return best;}

    private void generatePdf(){
        if(val("driver").trim().isEmpty()){toast("Please enter the driver's name.");return;}
        if(val("odoStart").isEmpty()||val("odoEnd").isEmpty()){toast("Enter or scan both odometer readings.");return;}
        double start,end; try{start=Double.parseDouble(val("odoStart"));end=Double.parseDouble(val("odoEnd"));}catch(Exception e){toast("Invalid odometer reading.");return;}
        if(end<start){toast("Arrival reading must not be lower than departure reading.");return;}
        try{
            // Use the exact blank 2024 BJMP Regional Office V PDF as the immutable page background.
            final int W=612,H=792, SCALE=3;
            Bitmap template=renderOriginalTemplate(SCALE);
            PdfDocument pdf=new PdfDocument();
            PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());
            Canvas c=page.getCanvas(); Paint imagePaint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
            c.drawBitmap(template,null,new RectF(0,0,W,H),imagePaint);
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTypeface(Typeface.create("tahoma",Typeface.BOLD)); p.setTextSize(15.0f);
            // All coordinates below are in PDF points, aligned to the blank uploaded form.
            drawFit(c,p,val("travelOrder"),184,166,269,9.4f);
            drawFit(c,p,val("date"),396,166,525,9.4f);
            drawFit(c,p,val("driver"),240,250,524,9.4f);
            drawFit(c,p,val("vehicle"),270,263,524,9.2f);
            drawFit(c,p,val("passengers"),270,276,524,9.0f);
            drawFit(c,p,val("places"),282,302,524,15.0f);
            drawFit(c,p,val("purpose"),141,328,524,9.0f);
            // Typed Warden / Chief of Bureau name sits immediately above the printed designation.
            drawFit(c,p,val("warden"),355,352,525,10.0f);
            // Section B: preserve all original printed labels and units; add values only on blank rules.
            drawFit(c,p,val("timeOut"),310,432,480,9.0f);
            drawFit(c,p,val("timeAtDestination"),310,445,480,9.0f);
            drawFit(c,p,val("timeFromDestination"),310,458,480,9.0f);
            drawFit(c,p,val("timeIn"),310,471,480,9.0f);
            drawFit(c,p,fmt(end-start),310,484,480,9.0f);
            drawFit(c,p,val("fuelIssued"),310,497,480,9.0f);
            drawFit(c,p,val("fuelBeginning"),185,510,480,9.0f);
            drawFit(c,p,val("fuelStock"),240,523,480,9.0f);
            drawFit(c,p,val("fuelPurchased"),310,536,480,9.0f);
            drawFit(c,p,val("fuelUsed"),310,549,480,9.0f);
            drawFit(c,p,val("fuelEnd"),310,562,480,9.0f);
            drawFit(c,p,val("gearOil"),310,575,480,9.0f);
            drawFit(c,p,val("lubricationOil"),240,588,480,9.0f);
            drawFit(c,p,val("greaseOil"),185,601,480,9.0f);
            drawFit(c,p,val("speedStart").isEmpty()?val("odoStart"):val("speedStart"),240,627,480,9.0f);
            drawFit(c,p,val("speedEnd").isEmpty()?val("odoEnd"):val("speedEnd"),185,640,480,9.0f);
            drawFit(c,p,val("remarks"),145,666,525,15.0f);
            // Additional remarks may use the next pre-printed blank line without changing the form.
            if(signature.hasInk()){
                Bitmap b=signature.getBitmap();
                c.drawBitmap(b,null,new RectF(353,707,525,726),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
            }
            drawFit(c,p,val("driverSignatory").isEmpty()?val("driver"):val("driverSignatory"),355,710,525,15.0f);
            template.recycle();
            pdf.finishPage(page);
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"TripTickets");dir.mkdirs();
            String safe=val("date").replaceAll("[^A-Za-z0-9-]","_"); File file=new File(dir,"TripTicket_"+safe+"_"+System.currentTimeMillis()+".pdf");
            FileOutputStream out=new FileOutputStream(file);pdf.writeTo(out);out.close();pdf.close();
            File gpsLog=new File(dir,file.getName().replace(".pdf","_GPS.txt")); try(FileWriter gw=new FileWriter(gpsLog)){gw.write("BJMP • SDJ TRIP TICKET - FOUR-STAGE PHOTO & GPS VERIFICATION\n");for(int i=1;i<=4;i++)gw.write("\n"+i+". "+PHOTO_LABELS[i]+"\nPhoto file: "+(evidencePhotoFiles[i].isEmpty()?"not attached":evidencePhotoFiles[i])+"\nLive GPS: "+liveGps[i]+"\nPhoto metadata: "+photoMeta[i]+"\n");}
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",file);share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Print or share original BJMP Trip Ticket PDF"));statusView.setText("Original BJMP blank-form layout filled and saved: "+file.getName());
        }catch(Exception e){toast("PDF error: "+e.getMessage());}
    }

    private Bitmap renderOriginalTemplate(int scale) throws Exception {
        File templateFile=new File(getCacheDir(),"trip-ticket-template.pdf");
        if(!templateFile.exists()){
            InputStream in=getAssets().open("trip_ticket_template.pdf"); FileOutputStream out=new FileOutputStream(templateFile);
            byte[] buffer=new byte[8192]; int n; while((n=in.read(buffer))>0)out.write(buffer,0,n); out.close(); in.close();
        }
        ParcelFileDescriptor fd=ParcelFileDescriptor.open(templateFile,ParcelFileDescriptor.MODE_READ_ONLY);
        PdfRenderer renderer=new PdfRenderer(fd); PdfRenderer.Page sourcePage=renderer.openPage(0);
        Bitmap bitmap=Bitmap.createBitmap(sourcePage.getWidth()*scale,sourcePage.getHeight()*scale,Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE); sourcePage.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
        sourcePage.close(); renderer.close(); fd.close(); return bitmap;
    }

    private void drawFit(Canvas c,Paint p,String value,float x,float baseline,float right,float size){
        if(value==null||value.trim().isEmpty())return;
        p.setTypeface(Typeface.create("tahoma",Typeface.BOLD)); p.setTextSize(Math.min(15.0f,Math.max(12.0f,size))); String text=value.replace("\n"," ").trim();
        float max=Math.max(10,right-x); while(p.measureText(text)>max && p.getTextSize()>8.0f)p.setTextSize(p.getTextSize()-0.25f);
        c.drawText(text,x,baseline,p);
    }
    private void rule(Canvas c,Paint p,float x1,float y,float x2){Paint q=new Paint(p);q.setStrokeWidth(0.65f);c.drawLine(x1,y,x2,y,q);}
    private int printField(Canvas c,Paint p,String label,String value,int x,int y,int right){c.drawText(label,x,y,p);float sx=Math.min(right-10,x+p.measureText(label)+5);rule(c,p,sx,y+3,right);if(value!=null&&!value.isEmpty())c.drawText(value,sx+3,y-1,p);return y+18;}
    private int printDriverRow(Canvas c,Paint p,String label,String value,String unit,int y){p.setTextSize(8.25f);c.drawText(label,75,y,p);rule(c,p,300,y+3,526);if(value!=null&&!value.isEmpty()){p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(value,305,y-1,p);}if(unit!=null&&!unit.isEmpty())c.drawText(unit,532,y,p);return y+15;}
    private void showHistory(){
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"TripTickets"); File[] files=dir.listFiles((d,n)->n.toLowerCase(Locale.US).endsWith(".pdf"));
        if(files==null||files.length==0){toast("No saved trip tickets yet.");return;}
        Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified())); String[] names=new String[files.length]; for(int i=0;i<files.length;i++)names[i]=files[i].getName();
        new AlertDialog.Builder(this).setTitle("Saved Trip Tickets").setItems(names,(dialog,which)->{try{Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(FileProvider.getUriForFile(this,getPackageName()+".provider",files[which]),"application/pdf");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(view);}catch(Exception ex){Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".provider",files[which]));share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Open or share PDF"));}}).setNegativeButton("Close",null).show();
    }
    private int header(Canvas c,Paint p,String s,int x,int y){p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(s,x,y,p);p.setTypeface(Typeface.DEFAULT);return y+20;}
    private int line(Canvas c,Paint p,String a,String b,int x,int y){c.drawText(a,x,y,p);if(b!=null)c.drawText(b,330,y,p);return y+19;}
    private void clearForm(){for(EditText e:fields.values())e.setText("");signature.clear();for(int i=1;i<=4;i++){photoMeta[i]="not captured";liveGps[i]="not captured";evidencePhotoFiles[i]="";if(photoPreviews[i]!=null){photoPreviews[i].setImageResource(android.R.drawable.ic_menu_camera);photoPreviews[i].setScaleType(ImageView.ScaleType.CENTER_INSIDE);}}updatePhotoMeta();updateDistance();statusView.setText("Form cleared.");}
    private String val(String k){EditText e=fields.get(k);return e==null?"":e.getText().toString();}
    private void section(String s){TextView t=text(s,14,true);t.setTextColor(Color.rgb(17,61,99));t.setPadding(dp(12),dp(13),dp(12),dp(9));t.setBackground(round(Color.rgb(224,235,246),10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(15);lp.bottomMargin=dp(5);form.addView(t,lp);}
    private void addField(String label,String key){addField(label,key,"");}
    private void addField(String label,String key,String value){addField(label,key,value,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);}
    private void addField(String label,String key,String value,int type){TextView l=text(label,12,true);l.setPadding(0,dp(7),0,dp(3));form.addView(l);EditText e=new EditText(this);e.setSingleLine(false);e.setMinLines(1);e.setTextSize(15);e.setTypeface(Typeface.create("tahoma",Typeface.BOLD));e.setPadding(dp(12),dp(9),dp(12),dp(9));e.setBackground(round(Color.WHITE,10));e.setInputType(type);e.setText(value);form.addView(e,new LinearLayout.LayoutParams(-1,dp(58)));fields.put(key,e);}
    private void addSuggestField(String label,String key,String[] suggestions){
        TextView l=text(label,12,true); l.setPadding(0,dp(7),0,dp(3)); form.addView(l);
        AutoCompleteTextView e=new AutoCompleteTextView(this);
        e.setSingleLine(false); e.setMinLines(1); e.setTextSize(17);
        e.setPadding(dp(14),dp(10),dp(14),dp(10)); e.setBackground(round(Color.WHITE,12));
        e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,suggestions);
        e.setAdapter(adapter); e.setThreshold(0); e.setOnClickListener(v->e.showDropDown());
        form.addView(e,new LinearLayout.LayoutParams(-1,dp(58))); fields.put(key,e);
    }

    private String[] loadList(String key,String[] defaults){
        String saved=getSharedPreferences("trip_ticket_masterlists",MODE_PRIVATE).getString(key,null);
        if(saved==null||saved.trim().isEmpty())return defaults;
        LinkedHashSet<String> values=new LinkedHashSet<>();
        for(String item:saved.split("\\n"))if(!item.trim().isEmpty())values.add(item.trim());
        for(String item:defaults)values.add(item);
        return values.toArray(new String[0]);
    }
    private void saveList(String key,List<String> values){
        getSharedPreferences("trip_ticket_masterlists",MODE_PRIVATE).edit().putString(key,String.join("\n",values)).apply();
    }
    private void manageMasterlists(){
        String[] sections={"Drivers","Vehicles","Destinations","Wardens / Chief of Bureau"};
        new AlertDialog.Builder(this).setTitle("Manage Masterlists").setItems(sections,(d,which)->{
            String key=which==0?"drivers":which==1?"vehicles":which==2?"destinations":"wardens";
            String[] defaults=which==0?DRIVER_SUGGESTIONS:which==1?VEHICLE_SUGGESTIONS:which==2?DESTINATION_SUGGESTIONS:new String[]{"JSINSP ISRAELITO D. BARRUN"};
            editMasterlist(sections[which],key,defaults);
        }).setNegativeButton("Close",null).show();
    }
    private void editMasterlist(String title,String key,String[] defaults){
        ArrayList<String> items=new ArrayList<>(Arrays.asList(loadList(key,defaults)));
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(16),dp(8),dp(16),0);
        EditText entry=new EditText(this);entry.setHint("Enter a new "+title.toLowerCase(Locale.US).replaceAll("s$","").trim());panel.addView(entry);
        ListView list=new ListView(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,items);list.setAdapter(adapter);panel.addView(list,new LinearLayout.LayoutParams(-1,dp(220)));
        TextView hint=text("Tap an item to remove it. Additions are saved on this phone and appear in the trip form dropdowns.",11,false);panel.addView(hint);
        list.setOnItemClickListener((parent,view,position,id)->new AlertDialog.Builder(this).setMessage("Remove \""+items.get(position)+"\" from this masterlist?").setPositiveButton("Remove",(a,b)->{items.remove(position);adapter.notifyDataSetChanged();saveList(key,items);}).setNegativeButton("Cancel",null).show());
        new AlertDialog.Builder(this).setTitle(title+" Masterlist").setView(panel).setPositiveButton("Add",(a,b)->{String value=entry.getText().toString().trim();if(!value.isEmpty()&&!items.contains(value))items.add(0,value);saveList(key,items);toast("Masterlist saved.");}).setNeutralButton("Save",(a,b)->{saveList(key,items);toast("Masterlist saved.");}).setNegativeButton("Close",null).show();
    }

    private void addButton(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.rgb(18,55,88));b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(220,232,244)));b.setOnClickListener(v->r.run());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.topMargin=dp(7);form.addView(b,lp);}
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    class SignatureView extends View {
        Paint paint=new Paint(3); Path path=new Path(); Bitmap bitmap; Canvas canvas;
        SignatureView(Context c){super(c);setBackgroundColor(Color.WHITE);paint.setColor(Color.BLACK);paint.setStrokeWidth(3);paint.setStyle(Paint.Style.STROKE);paint.setStrokeCap(Paint.Cap.ROUND);}
        protected void onDraw(Canvas c){super.onDraw(c);c.drawPath(path,paint);if(bitmap!=null)c.drawBitmap(bitmap,0,0,null);}
        public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();switch(e.getAction()){case MotionEvent.ACTION_DOWN:path.moveTo(x,y);invalidate();return true;case MotionEvent.ACTION_MOVE:path.lineTo(x,y);invalidate();return true;case MotionEvent.ACTION_UP:path.lineTo(x,y);invalidate();return true;}return true;}
        void clear(){path.reset();invalidate();} boolean hasInk(){return !path.isEmpty();} Bitmap getBitmap(){Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);Canvas cc=new Canvas(b);cc.drawColor(Color.WHITE);cc.drawPath(path,paint);return b;}
    }
}
