# SDJ Trip Ticket Android Project – Version 12 (Four-Stage Photo Evidence)

This update adds four required trip-stage photo slots:
1. Departure from jail/office
2. Arrival at destination
3. Departure from destination
4. Return to jail/office

Each selected photo is previewed in its own card and copied into the app's SDJTripEvidence pictures folder. The app attempts to read photo EXIF time and GPS metadata and separately requests a fresh live phone location for each stage. The four stage details and saved photo file paths are written to the GPS verification text file generated alongside the original BJMP Trip Ticket PDF.

Odometer OCR is run only on stage 1 (departure) and stage 4 (return), not on the destination photos. EXIF capture time is mapped to the corresponding trip-time field for each of the four stages.

The original BJMP Regional Office V blank PDF remains the PDF background and is not redesigned.

Build using the included GitHub Actions workflow. This source ZIP has not been compiled or device-tested in this environment. On Android, grant location permission and enable Location for live GPS capture. GPS may be unavailable indoors or in weak-signal areas; the app displays the unavailable status rather than fabricating coordinates.

Version 13: bold Tahoma-style 15sp app entries; bold Tahoma-style 15pt PDF overlay starting size with automatic fit-to-field; clearer vehicle kilometer reader labels. Android may substitute a similar sans-serif if Tahoma is unavailable.


Version 14 print alignment correction: shifted destination and remarks entries away from printed labels; moved driver signatory above the signature line and adjusted signature placement. Font remains bold, with a 15pt maximum and width-fit reduction down to 8pt when needed.

Version 15 visual update: replaced the generic vehicle hero artwork with the user's actual BJMP prisoner transport vehicle photo (cropped to the vehicle image, removing the phone gallery UI). Updated header wording and colors for a more official BJMP / Sipocot District Jail visual identity. Existing trip-ticket PDF template and trip-record logic are retained. The project has not yet been built or APK-tested.
