# SDJ Trip Ticket Android App v9

- Refreshed navy/blue card-based interface.
- Odometer OCR remains available with manual correction.
- Departure photo EXIF capture time fills the departure time; arrival photo EXIF capture time fills the return time.
- GPS coordinates embedded in the selected photo are read from EXIF. The app reverse-geocodes them where Android Geocoder is available; arrival GPS place fills the destination field.
- Driver, vehicle and destination masterlists remain editable on the device.
- Original blank BJMP Regional Office V PDF remains the print template.

Important: GPS and capture time are only available if the camera/photo file actually stores those EXIF tags. Screenshots, messaging-app compressed images, and photos taken with camera location tagging disabled may not contain GPS. In that case the app reports metadata missing; the user should enable camera location tagging and use the original photo, or enter details manually. EXIF metadata should be checked before official use.

## Version 9 updates
- Increased the target print text size for entered values across the original form (the app still fits long text to the available printed line).
- Added an editable Chief of Bureau / Warden name field. Warden names can be added or removed in the masterlist when the incumbent changes.
- Added a separate editable driver name field for the printed driver signatory below the certification. It defaults to the driver's entered name when left blank.
- The original blank BJMP Regional Office V PDF remains the background template; no printed labels or form layout were changed.
