# SDJ Trip Ticket Android App

Android source project for Sipocot District Jail Driver's Trip Ticket.

## Important print-output behavior
- The PDF generator uses `app/src/main/assets/trip_ticket_template.pdf` as the original, unchanged one-page BJMP Regional Office V blank form uploaded by the user.
- The app renders that PDF page as the background and places entered values on the blank lines. It does not redraw, redesign, replace, or retype the printed form labels, logos, numbering, or certification text.
- Output is a letter-size PDF (612 x 792 points) based on the uploaded blank form.
- Driver, vehicle, destinations, passengers, travel purpose, times, fuel/oil values, speedometer readings, remarks, odometer readings, and driver signature can be entered. Distance traveled is computed from arrival minus departure odometer readings.
- Odometer photo text recognition uses ML Kit; the detected number should always be checked by the driver before generating the ticket.

## Build
Open this folder in Android Studio and build the `app` module, or use the included GitHub Actions workflow to build a debug APK.
