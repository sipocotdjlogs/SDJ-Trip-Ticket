package com.sipocotdj.tripticket;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private LinearLayout root, form;
    private final Map<String, EditText> fields = new LinkedHashMap<>();
    private TextView distanceView, statusView;
    private SignatureView signature;
    private int scanTarget = 0; // 1 departure, 2 arrival
    private static final int PICK_IMAGE = 301;
    private static final String[] DRIVER_SUGGESTIONS = {
        "JO1 Carl Benedict C. Dineros", "JO1 Jomar V. Ibana", "JO1 Angelo Cutia",
        "JO1 John Ernest Chavez", "JO1 Turiano", "JO1 Lontoc", "JO1 Magdaraog",
        "JO1 Collantes", "JO1 Vince Rodrigo A. Roño", "JO1 Darwin Collantes",
        "JO1 Sarah Jane S. Ibarreta", "JO1 Kyla Graciel L. Orbita",
        "JO1 Ramelle A. Mandaraog", "JO1 Jeffrey Daep", "JO3 Ariel B. Pontanilla",
        "JO2 Jacell C. Acosta"
    };
    private static final String[] VEHICLE_SUGGESTIONS = {
        "Mitsubishi L300 / SAB 9894"
    };
    private static final String[] DESTINATION_SUGGESTIONS = {
        "Municipal Hall, Sipocot", "MCTC Sipocot", "RTC Libmanan",
        "BJMP Regional Office V, Legazpi City", "Provincial Jail, Pili, Camarines Sur",
        "Municipal Hall, Lupi", "Municipal Hall, Ragay", "Municipal Hall, Del Gallego",
        "Municipal Hall, Cabusao", "Municipal Hall, Libmanan", "Other - Enter Manually"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(16),dp(16),dp(24));
        root.setBackgroundColor(Color.rgb(246,248,251)); scroll.addView(root); setContentView(scroll);
        TextView title = text("BJMP SIPOCOT DISTRICT JAIL",20,true); title.setTextColor(Color.rgb(20,55,91)); root.addView(title);
        TextView sub = text("DRIVER'S TRIP TICKET • DIGITAL FORM",14,true); sub.setTextColor(Color.DKGRAY); root.addView(sub);
        statusView = text("Enter trip details. Scan odometer photos or type readings manually.",12,false); statusView.setPadding(0,dp(8),0,dp(8)); root.addView(statusView);
        form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); root.addView(form);
        section("TRAVEL DETAILS"); addField("Travel Order No.","travelOrder"); addField("Date (e.g. November 16, 2026)","date",new SimpleDateFormat("MMMM d, yyyy",Locale.US).format(new Date()));
        addSuggestField("Driver's Full Name (select or type) ","driver",loadList("drivers",DRIVER_SUGGESTIONS)); addSuggestField("Government Vehicle / Plate No. (select or type)","vehicle",loadList("vehicles",VEHICLE_SUGGESTIONS));
        addField("Authorized Passenger(s)","passengers"); addSuggestField("Place(s) to be Visited / Inspected (select or type) ","places",loadList("destinations",DESTINATION_SUGGESTIONS)); addField("Purpose of Travel","purpose");
        section("ODOMETER SCANNING & DISTANCE");
        addField("Departure Odometer Reading (KM)","odoStart","",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        addButton("📷 Scan Departure Odometer",()->pick(1));
        addField("Arrival Odometer Reading (KM)","odoEnd","",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        addButton("📷 Scan Arrival Odometer",()->pick(2));
        distanceView = text("DISTANCE TRAVELED: — KM",18,true); distanceView.setTextColor(Color.rgb(0,105,75)); distanceView.setPadding(0,dp(12),0,dp(12)); form.addView(distanceView);
        fields.get("odoStart").addTextChangedListener(watcher()); fields.get("odoEnd").addTextChangedListener(watcher());
        section("DRIVER'S TRIP RECORD");
        addField("Time of Departure from Office / Garage","timeOut"); addField("Time of Arrival at Destination","timeAtDestination"); addField("Time of Departure from Destination","timeFromDestination"); addField("Time of Arrival Back to Office / Garage","timeIn");
        addField("Gasoline Issued / Purchased / Consumed (Liters)","fuelIssued"); addField("Balance in Tank at Beginning (Liters)","fuelBeginning"); addField("Issued by Office from Stock (Liters)","fuelStock"); addField("Fuel Purchased During Trip (Liters)","fuelPurchased"); addField("Fuel Deducted / Used During Trip (Liters)","fuelUsed"); addField("Balance in Tank at End (Liters)","fuelEnd");
        addField("Gear Oil Issued (Liters)","gearOil"); addField("Lubrication Oil Issued (Liters)","lubricationOil"); addField("Grease Oil Issued (Liters)","greaseOil"); addField("Speedometer Reading at Beginning (KM)","speedStart"); addField("Speedometer Reading at End (KM)","speedEnd"); addField("Remarks","remarks");
        section("DRIVER SIGNATORY");
        TextView sigHint=text("Driver: the name entered above will appear below the certification. Draw signature here (optional).",12,false); form.addView(sigHint);
        signature = new SignatureView(this); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(130)); sp.topMargin=dp(8); sp.bottomMargin=dp(8); signature.setLayoutParams(sp); form.addView(signature);
        addButton("Clear Signature",()->signature.clear());
        addButton("MANAGE DRIVER & VEHICLE MASTERLISTS",()->manageMasterlists());
        addButton("GENERATE TRIP TICKET PDF",()->generatePdf());
        addButton("VIEW SAVED TRIP TICKETS",()->showHistory());
        addButton("CLEAR FORM",()->new AlertDialog.Builder(this).setMessage("Clear all entered trip details?").setPositiveButton("Clear",(d,w)->clearForm()).setNegativeButton("Cancel",null).show());
    }

    private android.text.TextWatcher watcher(){return new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){updateDistance();} public void afterTextChanged(android.text.Editable e){}};}
    private void updateDistance(){try{double a=Double.parseDouble(val("odoStart")),b=Double.parseDouble(val("odoEnd")); double d=b-a; distanceView.setText(d<0?"CHECK READINGS: Arrival is lower than departure":"DISTANCE TRAVELED: "+fmt(d)+" KM");}catch(Exception e){distanceView.setText("DISTANCE TRAVELED: — KM");}}
    private String fmt(double n){return n==(long)n?String.valueOf((long)n):String.format(Locale.US,"%.1f",n);}
    private void pick(int target){scanTarget=target; Intent i=new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(Intent.createChooser(i,"Take a photo or choose odometer image"),PICK_IMAGE);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data); if(req==PICK_IMAGE&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData(); statusView.setText("Reading odometer image… please wait."); try{InputImage image=InputImage.fromFilePath(this,uri); TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image).addOnSuccessListener(result->{String found=findReading(result.getText()); if(found!=null){fields.get(scanTarget==1?"odoStart":"odoEnd").setText(found); statusView.setText("Detected reading: "+found+" KM. Please verify it against the photo.");}else statusView.setText("No clear odometer number detected. Please type the reading manually.");}).addOnFailureListener(e->statusView.setText("Could not read image. Please enter the odometer manually."));}catch(Exception e){statusView.setText("Unable to open image. Please try another photo.");}}}
    private String findReading(String s){Matcher m=Pattern.compile("(?<!\\d)(\\d{2,7}(?:[,.]\\d)?)(?!\\d)").matcher(s.replace(" ","")); String best=null; int max=-1; while(m.find()){String x=m.group(1).replace(",",""); try{int n=(int)Double.parseDouble(x); if(n>max){max=n;best=x;}}catch(Exception ignored){}} return best;}

    private void generatePdf(){
        if(val("driver").trim().isEmpty()){toast("Please enter the driver's name.");return;}
        if(val("odoStart").isEmpty()||val("odoEnd").isEmpty()){toast("Enter or scan both odometer readings.");return;}
        double start,end; try{start=Double.parseDouble(val("odoStart"));end=Double.parseDouble(val("odoEnd"));}catch(Exception e){toast("Invalid odometer reading.");return;}
        if(end<start){toast("Arrival reading must not be lower than departure reading.");return;}
        try{
            // Use the exact blank 2024 BJMP Regional Office V PDF as the immutable page background.
            final int W=612,H=792, SCALE=3;
            Bitmap template=renderOriginalTemplate(SCALE);
            PdfDocument pdf=new PdfDocument();
            PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());
            Canvas c=page.getCanvas(); Paint imagePaint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
            c.drawBitmap(template,null,new RectF(0,0,W,H),imagePaint);
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextSize(8.0f);
            // All coordinates below are in PDF points, aligned to the blank uploaded form.
            drawFit(c,p,val("travelOrder"),184,166,269,8.2f);
            drawFit(c,p,val("date"),396,166,525,8.2f);
            drawFit(c,p,val("driver"),240,250,524,8.0f);
            drawFit(c,p,val("vehicle"),270,263,524,8.0f);
            drawFit(c,p,val("passengers"),270,276,524,7.8f);
            drawFit(c,p,val("places"),270,302,524,7.8f);
            drawFit(c,p,val("purpose"),141,328,524,7.8f);
            // Section B: preserve all original printed labels and units; add values only on blank rules.
            drawFit(c,p,val("timeOut"),310,432,480,7.8f);
            drawFit(c,p,val("timeAtDestination"),310,445,480,7.8f);
            drawFit(c,p,val("timeFromDestination"),310,458,480,7.8f);
            drawFit(c,p,val("timeIn"),310,471,480,7.8f);
            drawFit(c,p,fmt(end-start),310,484,480,7.8f);
            drawFit(c,p,val("fuelIssued"),310,497,480,7.8f);
            drawFit(c,p,val("fuelBeginning"),185,510,480,7.8f);
            drawFit(c,p,val("fuelStock"),240,523,480,7.8f);
            drawFit(c,p,val("fuelPurchased"),310,536,480,7.8f);
            drawFit(c,p,val("fuelUsed"),310,549,480,7.8f);
            drawFit(c,p,val("fuelEnd"),310,562,480,7.8f);
            drawFit(c,p,val("gearOil"),310,575,480,7.8f);
            drawFit(c,p,val("lubricationOil"),240,588,480,7.8f);
            drawFit(c,p,val("greaseOil"),185,601,480,7.8f);
            drawFit(c,p,val("speedStart").isEmpty()?val("odoStart"):val("speedStart"),240,627,480,7.8f);
            drawFit(c,p,val("speedEnd").isEmpty()?val("odoEnd"):val("speedEnd"),185,640,480,7.8f);
            drawFit(c,p,val("remarks"),145,653,525,7.8f);
            // Additional remarks may use the next pre-printed blank line without changing the form.
            if(signature.hasInk()){
                Bitmap b=signature.getBitmap();
                c.drawBitmap(b,null,new RectF(353,716,525,733),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
            }
            drawFit(c,p,val("driver"),418,739,525,7.6f);
            template.recycle();
            pdf.finishPage(page);
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"TripTickets");dir.mkdirs();
            String safe=val("date").replaceAll("[^A-Za-z0-9-]","_"); File file=new File(dir,"TripTicket_"+safe+"_"+System.currentTimeMillis()+".pdf");
            FileOutputStream out=new FileOutputStream(file);pdf.writeTo(out);out.close();pdf.close();
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",file);share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Print or share original BJMP Trip Ticket PDF"));statusView.setText("Original BJMP blank-form layout filled and saved: "+file.getName());
        }catch(Exception e){toast("PDF error: "+e.getMessage());}
    }

    private Bitmap renderOriginalTemplate(int scale) throws Exception {
        File templateFile=new File(getCacheDir(),"trip-ticket-template.pdf");
        if(!templateFile.exists()){
            InputStream in=getAssets().open("trip_ticket_template.pdf"); FileOutputStream out=new FileOutputStream(templateFile);
            byte[] buffer=new byte[8192]; int n; while((n=in.read(buffer))>0)out.write(buffer,0,n); out.close(); in.close();
        }
        ParcelFileDescriptor fd=ParcelFileDescriptor.open(templateFile,ParcelFileDescriptor.MODE_READ_ONLY);
        PdfRenderer renderer=new PdfRenderer(fd); PdfRenderer.Page sourcePage=renderer.openPage(0);
        Bitmap bitmap=Bitmap.createBitmap(sourcePage.getWidth()*scale,sourcePage.getHeight()*scale,Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE); sourcePage.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
        sourcePage.close(); renderer.close(); fd.close(); return bitmap;
    }

    private void drawFit(Canvas c,Paint p,String value,float x,float baseline,float right,float size){
        if(value==null||value.trim().isEmpty())return;
        p.setTextSize(size); String text=value.replace("\n"," ").trim();
        float max=Math.max(10,right-x); while(p.measureText(text)>max && p.getTextSize()>5.2f)p.setTextSize(p.getTextSize()-0.25f);
        c.drawText(text,x,baseline,p);
    }
    private void rule(Canvas c,Paint p,float x1,float y,float x2){Paint q=new Paint(p);q.setStrokeWidth(0.65f);c.drawLine(x1,y,x2,y,q);}
    private int printField(Canvas c,Paint p,String label,String value,int x,int y,int right){c.drawText(label,x,y,p);float sx=Math.min(right-10,x+p.measureText(label)+5);rule(c,p,sx,y+3,right);if(value!=null&&!value.isEmpty())c.drawText(value,sx+3,y-1,p);return y+18;}
    private int printDriverRow(Canvas c,Paint p,String label,String value,String unit,int y){p.setTextSize(8.25f);c.drawText(label,75,y,p);rule(c,p,300,y+3,526);if(value!=null&&!value.isEmpty()){p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(value,305,y-1,p);}if(unit!=null&&!unit.isEmpty())c.drawText(unit,532,y,p);return y+15;}
    private void showHistory(){
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"TripTickets"); File[] files=dir.listFiles((d,n)->n.toLowerCase(Locale.US).endsWith(".pdf"));
        if(files==null||files.length==0){toast("No saved trip tickets yet.");return;}
        Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified())); String[] names=new String[files.length]; for(int i=0;i<files.length;i++)names[i]=files[i].getName();
        new AlertDialog.Builder(this).setTitle("Saved Trip Tickets").setItems(names,(dialog,which)->{try{Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(FileProvider.getUriForFile(this,getPackageName()+".provider",files[which]),"application/pdf");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(view);}catch(Exception ex){Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".provider",files[which]));share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Open or share PDF"));}}).setNegativeButton("Close",null).show();
    }
    private int header(Canvas c,Paint p,String s,int x,int y){p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(s,x,y,p);p.setTypeface(Typeface.DEFAULT);return y+20;}
    private int line(Canvas c,Paint p,String a,String b,int x,int y){c.drawText(a,x,y,p);if(b!=null)c.drawText(b,330,y,p);return y+19;}
    private void clearForm(){for(EditText e:fields.values())e.setText("");signature.clear();updateDistance();statusView.setText("Form cleared.");}
    private String val(String k){EditText e=fields.get(k);return e==null?"":e.getText().toString();}
    private void section(String s){TextView t=text(s,14,true);t.setTextColor(Color.rgb(25,75,115));t.setPadding(0,dp(15),0,dp(6));form.addView(t);}
    private void addField(String label,String key){addField(label,key,"");}
    private void addField(String label,String key,String value){addField(label,key,value,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);}
    private void addField(String label,String key,String value,int type){TextView l=text(label,12,true);l.setPadding(0,dp(7),0,dp(3));form.addView(l);EditText e=new EditText(this);e.setSingleLine(false);e.setMinLines(1);e.setTextSize(14);e.setPadding(dp(10),dp(7),dp(10),dp(7));e.setBackgroundColor(Color.WHITE);e.setInputType(type);e.setText(value);form.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));fields.put(key,e);}
    private void addSuggestField(String label,String key,String[] suggestions){
        TextView l=text(label,12,true); l.setPadding(0,dp(7),0,dp(3)); form.addView(l);
        AutoCompleteTextView e=new AutoCompleteTextView(this);
        e.setSingleLine(false); e.setMinLines(1); e.setTextSize(14);
        e.setPadding(dp(10),dp(7),dp(10),dp(7)); e.setBackgroundColor(Color.WHITE);
        e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,suggestions);
        e.setAdapter(adapter); e.setThreshold(0); e.setOnClickListener(v->e.showDropDown());
        form.addView(e,new LinearLayout.LayoutParams(-1,dp(52))); fields.put(key,e);
    }

    private String[] loadList(String key,String[] defaults){
        String saved=getSharedPreferences("trip_ticket_masterlists",MODE_PRIVATE).getString(key,null);
        if(saved==null||saved.trim().isEmpty())return defaults;
        LinkedHashSet<String> values=new LinkedHashSet<>();
        for(String item:saved.split("\\n"))if(!item.trim().isEmpty())values.add(item.trim());
        for(String item:defaults)values.add(item);
        return values.toArray(new String[0]);
    }
    private void saveList(String key,List<String> values){
        getSharedPreferences("trip_ticket_masterlists",MODE_PRIVATE).edit().putString(key,String.join("\n",values)).apply();
    }
    private void manageMasterlists(){
        String[] sections={"Drivers","Vehicles","Destinations"};
        new AlertDialog.Builder(this).setTitle("Manage Masterlists").setItems(sections,(d,which)->{
            String key=which==0?"drivers":which==1?"vehicles":"destinations";
            String[] defaults=which==0?DRIVER_SUGGESTIONS:which==1?VEHICLE_SUGGESTIONS:DESTINATION_SUGGESTIONS;
            editMasterlist(sections[which],key,defaults);
        }).setNegativeButton("Close",null).show();
    }
    private void editMasterlist(String title,String key,String[] defaults){
        ArrayList<String> items=new ArrayList<>(Arrays.asList(loadList(key,defaults)));
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(16),dp(8),dp(16),0);
        EditText entry=new EditText(this);entry.setHint("Enter a new "+title.toLowerCase(Locale.US).replaceAll("s$","").trim());panel.addView(entry);
        ListView list=new ListView(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,items);list.setAdapter(adapter);panel.addView(list,new LinearLayout.LayoutParams(-1,dp(220)));
        TextView hint=text("Tap an item to remove it. Additions are saved on this phone and appear in the trip form dropdowns.",11,false);panel.addView(hint);
        list.setOnItemClickListener((parent,view,position,id)->new AlertDialog.Builder(this).setMessage("Remove \""+items.get(position)+"\" from this masterlist?").setPositiveButton("Remove",(a,b)->{items.remove(position);adapter.notifyDataSetChanged();saveList(key,items);}).setNegativeButton("Cancel",null).show());
        new AlertDialog.Builder(this).setTitle(title+" Masterlist").setView(panel).setPositiveButton("Add",(a,b)->{String value=entry.getText().toString().trim();if(!value.isEmpty()&&!items.contains(value))items.add(0,value);saveList(key,items);toast("Masterlist saved.");}).setNeutralButton("Save",(a,b)->{saveList(key,items);toast("Masterlist saved.");}).setNegativeButton("Close",null).show();
    }

    private void addButton(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setOnClickListener(v->r.run());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.topMargin=dp(7);form.addView(b,lp);}
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    class SignatureView extends View {
        Paint paint=new Paint(3); Path path=new Path(); Bitmap bitmap; Canvas canvas;
        SignatureView(Context c){super(c);setBackgroundColor(Color.WHITE);paint.setColor(Color.BLACK);paint.setStrokeWidth(3);paint.setStyle(Paint.Style.STROKE);paint.setStrokeCap(Paint.Cap.ROUND);}
        protected void onDraw(Canvas c){super.onDraw(c);c.drawPath(path,paint);if(bitmap!=null)c.drawBitmap(bitmap,0,0,null);}
        public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();switch(e.getAction()){case MotionEvent.ACTION_DOWN:path.moveTo(x,y);invalidate();return true;case MotionEvent.ACTION_MOVE:path.lineTo(x,y);invalidate();return true;case MotionEvent.ACTION_UP:path.lineTo(x,y);invalidate();return true;}return true;}
        void clear(){path.reset();invalidate();} boolean hasInk(){return !path.isEmpty();} Bitmap getBitmap(){Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);Canvas cc=new Canvas(b);cc.drawColor(Color.WHITE);cc.drawPath(path,paint);return b;}
    }
}
